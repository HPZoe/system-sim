Estructura de carpetas (solo directorios). Para usar en NetBeans, cree un proyecto Maven aquí o añada un pom.xml.
